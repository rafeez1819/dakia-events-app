//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BI1vbvWg.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/intel",
			"/privacy",
			"/terms",
			"/api/collect",
			"/api/contact"
		],
		preloads: ["/assets/index-BIvYVroS.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BIvYVroS.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		css: ["/assets/routes-1qHNqDoe.css"],
		preloads: ["/assets/routes-Cwv4BQmY.js", "/assets/warehouse-Dxjyu7a2.js"]
	},
	"/intel": {
		filePath: "/workspace/src/routes/intel.tsx",
		children: void 0,
		preloads: ["/assets/intel-CvUf7b2x.js", "/assets/warehouse-Dxjyu7a2.js"]
	},
	"/privacy": {
		filePath: "/workspace/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-CjGQIUlI.js", "/assets/LegalShell-BkE6gUWU.js"]
	},
	"/terms": {
		filePath: "/workspace/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-BMPTmGwX.js", "/assets/LegalShell-BkE6gUWU.js"]
	}
} });
//#endregion
export { tsrStartManifest };
