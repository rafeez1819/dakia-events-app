import { a as CITIES$1, i as CHANNELS, s as EVENT_VALUE_AED, u as PRODUCT_TYPES } from "./router-DYfd_llS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/warehouse-DwHepNPs.js
var KEY = "dakia_consent_v2";
var DENIED = {
	analytics_storage: "denied",
	ad_storage: "denied",
	ad_user_data: "denied",
	ad_personalization: "denied",
	decided: false,
	updatedAt: null
};
function loadConsent() {
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return { ...DENIED };
		const parsed = JSON.parse(raw);
		if (parsed.analytics_storage !== "granted" && parsed.analytics_storage !== "denied") return { ...DENIED };
		return parsed;
	} catch {
		return { ...DENIED };
	}
}
function saveConsent(next) {
	localStorage.setItem(KEY, JSON.stringify(next));
}
function applyGtagConsent(state) {
	const gtag = window.gtag;
	if (typeof gtag !== "function") return;
	gtag("consent", "update", {
		analytics_storage: state.analytics_storage,
		ad_storage: state.ad_storage,
		ad_user_data: state.ad_user_data,
		ad_personalization: state.ad_personalization
	});
}
function mulberry(seed) {
	let a = seed >>> 0;
	return () => {
		a += 1831565813;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t ^= t + Math.imul(t ^ t >>> 7, 61 | t);
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
var EVENT_WEIGHTS = [
	["page_view", 1],
	["user_engagement", .62],
	["scroll", .38],
	["product_view", .34],
	["led_product_view", .22],
	["project_view", .18],
	["fiba_project_view", .07],
	["concert_project_view", .06],
	["exhibition_project_view", .05],
	["form_start", .09],
	["quotation_start", .07],
	["quotation_submit", .028],
	["contact_form_submit", .026],
	["lead_generated", .026],
	["whatsapp_click", .045],
	["phone_click", .032],
	["email_click", .018],
	["led_quote_request", .012]
];
function buildHistory(days = 90, seed = 20260821) {
	const rand = mulberry(seed);
	const daily = [];
	const events = [];
	const leads = [];
	const today = /* @__PURE__ */ new Date();
	today.setHours(12, 0, 0, 0);
	for (let i = days - 1; i >= 0; i--) {
		const d = new Date(today);
		d.setDate(d.getDate() - i);
		const iso = d.toISOString().slice(0, 10);
		const dow = d.getDay();
		const weekend = dow === 5 || dow === 6;
		const wave = 1 + .18 * Math.sin(i / days * Math.PI * 2);
		const campaignBoost = i % 17 === 0 ? 1.35 : 1;
		const users = Math.round((weekend ? 70 : 128) * wave * campaignBoost * (.85 + rand() * .3));
		const sessions = Math.round(users * (1.15 + rand() * .2));
		const newUsers = Math.round(users * (.42 + rand() * .12));
		const engagedSessions = Math.round(sessions * (.58 + rand() * .12));
		const pageViews = Math.round(sessions * (2.4 + rand() * .8));
		const channels = {};
		const channelShare = [
			.31,
			.14,
			.18,
			.09,
			.16,
			.06,
			.04,
			.02
		];
		CHANNELS.forEach((ch, idx) => {
			channels[ch] = Math.max(1, Math.round(users * channelShare[idx] * (.8 + rand() * .4)));
		});
		const devices = {
			mobile: Math.round(users * .68),
			desktop: Math.round(users * .27),
			tablet: Math.max(0, users - Math.round(users * .68) - Math.round(users * .27))
		};
		const geos = {};
		const geoShare = [
			.38,
			.22,
			.12,
			.09,
			.05,
			.04,
			.06,
			.04
		];
		CITIES$1.forEach((city, idx) => {
			geos[city] = Math.max(0, Math.round(users * geoShare[idx] * (.85 + rand() * .3)));
		});
		const eventCounts = {};
		for (const [name, w] of EVENT_WEIGHTS) eventCounts[name] = Math.max(0, Math.round(users * w * (.75 + rand() * .5)));
		eventCounts.page_view = pageViews;
		const conversions = (eventCounts.quotation_submit ?? 0) + (eventCounts.whatsapp_click ?? 0) + (eventCounts.phone_click ?? 0);
		const conversionValue = (eventCounts.quotation_submit ?? 0) * EVENT_VALUE_AED.quotation_submit + (eventCounts.whatsapp_click ?? 0) * EVENT_VALUE_AED.whatsapp_click + (eventCounts.phone_click ?? 0) * EVENT_VALUE_AED.phone_click;
		const leadN = eventCounts.lead_generated ?? 0;
		const qualifiedLeads = Math.round(leadN * (.38 + rand() * .15));
		daily.push({
			date: iso,
			users,
			newUsers,
			sessions,
			engagedSessions,
			pageViews,
			avgEngagementSec: Math.round(42 + rand() * 38),
			channels,
			devices,
			geos,
			events: eventCounts,
			conversions,
			conversionValue,
			leads: leadN,
			qualifiedLeads
		});
		const sampleN = i < 8 ? 18 : i < 21 ? 6 : 0;
		for (let k = 0; k < sampleN; k++) {
			const [ev] = EVENT_WEIGHTS[Math.floor(rand() * EVENT_WEIGHTS.length)];
			const city = CITIES$1[Math.floor(rand() * CITIES$1.length)];
			const device = rand() > .68 ? "desktop" : rand() > .08 ? "mobile" : "tablet";
			const ts = d.getTime() + Math.floor(rand() * 864e5);
			events.push({
				event: ev,
				timestamp: ts,
				client_id: `cid.seed${Math.floor(rand() * 9e4)}`,
				session_id: `sid.seed${Math.floor(rand() * 9e4)}`,
				params: {
					page_location: "https://dakiaevents.com/",
					content_group: [
						"home",
						"services",
						"events",
						"projects",
						"contact"
					][Math.floor(rand() * 5)],
					city,
					device_category: device,
					lead_source: CHANNELS[Math.floor(rand() * CHANNELS.length)]
				}
			});
		}
		const leadSample = i < 21 ? Math.min(leadN, 3 + Math.floor(rand() * 4)) : 0;
		for (let k = 0; k < leadSample; k++) {
			const pages = 2 + Math.floor(rand() * 7);
			const product = PRODUCT_TYPES[Math.floor(rand() * PRODUCT_TYPES.length)];
			const source = CHANNELS[Math.floor(rand() * 5)];
			let score = 20 + pages * 6;
			if (product === "LED_VIDEO_WALL") score += 12;
			if (source === "linkedin" || source === "paid") score += 10;
			const device = rand() > .45 ? "desktop" : "mobile";
			if (device === "desktop") score += 8;
			score = Math.min(99, Math.round(score + rand() * 10));
			const band = score >= 81 ? "very_high" : score >= 61 ? "high" : score >= 31 ? "medium" : "low";
			leads.push({
				id: `ld-${iso}-${k}`,
				ts: d.getTime() + Math.floor(rand() * 864e5),
				eventType: [
					"Sports / FIBA",
					"Corporate Event",
					"Music Concert",
					"Exhibition",
					"Conference"
				][Math.floor(rand() * 5)],
				productType: product,
				source,
				city: CITIES$1[Math.floor(rand() * 4)],
				device,
				score,
				band,
				qualified: score >= 61
			});
		}
	}
	return {
		daily,
		events: events.slice(-500),
		leads: leads.slice(-180)
	};
}
var LIVE_KEY = "dakia_live_events_v1";
var PAGES = [
	"/",
	"/#services",
	"/#events",
	"/#projects",
	"/#contact",
	"/#capabilities"
];
var CITIES = [
	"Dubai",
	"Abu Dhabi",
	"Sharjah",
	"Ajman",
	"Riyadh"
];
function loadLive() {
	try {
		const raw = localStorage.getItem(LIVE_KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) ? parsed.slice(-400) : [];
	} catch {
		return [];
	}
}
function saveLive(events) {
	try {
		localStorage.setItem(LIVE_KEY, JSON.stringify(events.slice(-400)));
	} catch {}
}
var Warehouse = class {
	daily = [];
	sampleEvents = [];
	leads = [];
	live = [];
	realtime = [];
	listeners = /* @__PURE__ */ new Set();
	ready = false;
	init() {
		if (this.ready) return;
		const hist = buildHistory(90);
		this.daily = hist.daily;
		this.sampleEvents = hist.events;
		this.leads = hist.leads;
		this.live = loadLive();
		this.realtime = this.seedRealtime();
		this.ready = true;
		this.emit();
	}
	seedRealtime() {
		const n = 18 + Math.floor(Math.random() * 16);
		return Array.from({ length: n }, (_, i) => ({
			id: `rt-${i}`,
			city: CITIES[i % CITIES.length],
			page: PAGES[i % PAGES.length],
			device: i % 5 === 0 ? "desktop" : i % 9 === 0 ? "tablet" : "mobile",
			since: Date.now() - Math.floor(Math.random() * 8 * 6e4)
		}));
	}
	append(event) {
		this.live = [...this.live, event].slice(-400);
		saveLive(this.live);
		const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
		const row = this.daily[this.daily.length - 1];
		if (row && row.date === today) {
			row.events[event.event] = (row.events[event.event] ?? 0) + 1;
			if (event.event === "page_view") {
				row.pageViews += 1;
				row.users += 1;
				row.sessions += 1;
			}
			if (event.event === "lead_generated" || event.event === "quotation_submit") {
				row.leads += 1;
				row.conversions += 1;
			}
		}
		this.emit();
	}
	subscribe(fn) {
		this.listeners.add(fn);
		return () => {
			this.listeners.delete(fn);
		};
	}
	emit() {
		this.listeners.forEach((fn) => fn());
	}
	allEvents() {
		return [...this.sampleEvents, ...this.live].slice(-500);
	}
};
var warehouse = new Warehouse();
//#endregion
export { warehouse as i, loadConsent as n, saveConsent as r, applyGtagConsent as t };
