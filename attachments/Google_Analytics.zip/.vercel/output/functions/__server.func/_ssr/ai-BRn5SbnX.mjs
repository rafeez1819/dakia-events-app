import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-BRn5SbnX.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var generateDailyIntelligence_createServerFn_handler = createServerRpc({
	id: "9fcfb67a1ddb797c5252384dcd5259962da8b397c956eca5b01d9ac764e0f760",
	name: "generateDailyIntelligence",
	filename: "src/lib/analytics/ai.ts"
}, (opts) => generateDailyIntelligence.__executeServer(opts));
var generateDailyIntelligence = createServerFn({ method: "POST" }).validator((input) => input).handler(generateDailyIntelligence_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "AI is not available in this environment",
		text: fallbackCopy(data.summary)
	};
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			max_tokens: 700,
			messages: [{
				role: "system",
				content: "You are the Dakia Events Website Intelligence analyst. Write a concise daily briefing for a UAE LED/AV production company. No PII. Use short labeled sections: Traffic, Leads, Channel, Funnel bottleneck, Anomaly, Forecast, Recommended action. Plain language. Do not invent raw user identities."
			}, {
				role: "user",
				content: `Aggregated metrics (no personal data):\n${JSON.stringify(data.summary)}`
			}]
		})
	});
	if (!res.ok) return {
		ok: false,
		error: `xAI API error ${res.status}`,
		text: fallbackCopy(data.summary)
	};
	return {
		ok: true,
		text: (await res.json()).choices[0]?.message.content ?? fallbackCopy(data.summary)
	};
});
function fallbackCopy(s) {
	const ch = s.topChannel?.name ?? "organic";
	const geo = s.topGeo?.name ?? "Dubai";
	const drop = s.funnel.find((f, i, arr) => i > 0 && arr[i - 1] && f.count / Math.max(arr[i - 1].count, 1) < .35);
	return [
		"DAILY WEBSITE INTELLIGENCE",
		`Traffic  ${s.users.toLocaleString()} users (${s.usersDeltaPct >= 0 ? "+" : ""}${s.usersDeltaPct}%)`,
		`Leads  ${s.leads} (${s.leadsDeltaPct >= 0 ? "+" : ""}${s.leadsDeltaPct}%) · ${s.qualifiedLeads} qualified`,
		`Conversion  ${s.conversionRatePct}% · AED ${s.conversionValueAED.toLocaleString()} assigned lead value`,
		`Highest-performing channel  ${ch}`,
		`Highest-intent geography  ${geo}`,
		`Funnel pressure  ${drop ? drop.label : "Quote submit"} is the tightest step`,
		`Detected anomaly  ${s.anomalies[0] ? `${s.anomalies[0].metric} ${s.anomalies[0].direction} on ${s.anomalies[0].date}` : "None above threshold"}`,
		`Forecast  Next 30 days ~ ${s.forecast30Leads} leads`,
		"Recommended action  Investigate the mobile quotation path — desktop still converts harder — and increase Sports/FIBA campaign exposure on LinkedIn."
	].join("\n");
}
//#endregion
export { generateDailyIntelligence_createServerFn_handler };
