import { createFileRoute } from "@tanstack/react-router";
import { PII_KEYS } from "@/lib/analytics/config";
import { sanitizeEventName } from "@/lib/analytics/sanitize";

const PII = new Set<string>(PII_KEYS);
const ring: Array<{ event: string; at: number }> = [];

function strip(params: unknown): Record<string, unknown> {
  if (!params || typeof params !== "object") return {};
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(params as Record<string, unknown>)) {
    if (PII.has(k) || /email|phone|name|address/i.test(k)) continue;
    if (typeof v === "string") out[k] = v.slice(0, 200);
    else if (typeof v === "number" || typeof v === "boolean") out[k] = v;
  }
  return out;
}

export const Route = createFileRoute("/api/collect")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let body: Record<string, unknown> = {};
        try {
          const ct = request.headers.get("content-type") || "";
          if (ct.includes("json")) body = (await request.json()) as Record<string, unknown>;
          else body = JSON.parse(await request.text()) as Record<string, unknown>;
        } catch {
          return Response.json({ ok: false, message: "Invalid payload" }, { status: 400 });
        }
        const event = sanitizeEventName(String(body.event || ""));
        if (!event) return Response.json({ ok: false, message: "Missing event" }, { status: 400 });
        strip(body.params);
        ring.push({ event, at: Date.now() });
        if (ring.length > 500) ring.shift();
        return Response.json({ ok: true });
      },
    },
  },
});
