import { createFileRoute } from "@tanstack/react-router";
import { AnalyticsRoot } from "@/components/analytics/AnalyticsRoot";
import { DakiaSite } from "@/components/site/DakiaSite";

export const Route = createFileRoute("/")({
  component: Home,
  head: () => ({
    meta: [{ title: "Dakia Events | LED Video Walls, AV & Event Production UAE" }],
  }),
});

function Home() {
  return (
    <AnalyticsRoot>
      <DakiaSite />
    </AnalyticsRoot>
  );
}
