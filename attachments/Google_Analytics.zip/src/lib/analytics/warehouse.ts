import { buildHistory } from "./seed";
import type { AnalyticsEvent, DailyRollup, LeadRecord, RealtimeVisitor } from "./types";

const LIVE_KEY = "dakia_live_events_v1";
const PAGES = ["/", "/#services", "/#events", "/#projects", "/#contact", "/#capabilities"];
const CITIES = ["Dubai", "Abu Dhabi", "Sharjah", "Ajman", "Riyadh"];

function loadLive(): AnalyticsEvent[] {
  try {
    const raw = localStorage.getItem(LIVE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as AnalyticsEvent[];
    return Array.isArray(parsed) ? parsed.slice(-400) : [];
  } catch {
    return [];
  }
}

function saveLive(events: AnalyticsEvent[]) {
  try {
    localStorage.setItem(LIVE_KEY, JSON.stringify(events.slice(-400)));
  } catch {
    /* quota */
  }
}

class Warehouse {
  daily: DailyRollup[] = [];
  sampleEvents: AnalyticsEvent[] = [];
  leads: LeadRecord[] = [];
  live: AnalyticsEvent[] = [];
  realtime: RealtimeVisitor[] = [];
  listeners = new Set<() => void>();
  ready = false;

  init() {
    if (this.ready) return;
    const hist = buildHistory(90);
    this.daily = hist.daily;
    this.sampleEvents = hist.events;
    this.leads = hist.leads;
    this.live = loadLive();
    this.realtime = this.seedRealtime();
    this.ready = true;
    this.emit();
  }

  seedRealtime(): RealtimeVisitor[] {
    const n = 18 + Math.floor(Math.random() * 16);
    return Array.from({ length: n }, (_, i) => ({
      id: `rt-${i}`,
      city: CITIES[i % CITIES.length]!,
      page: PAGES[i % PAGES.length]!,
      device: i % 5 === 0 ? "desktop" : i % 9 === 0 ? "tablet" : "mobile",
      since: Date.now() - Math.floor(Math.random() * 8 * 60_000),
    }));
  }

  append(event: AnalyticsEvent) {
    this.live = [...this.live, event].slice(-400);
    saveLive(this.live);
    const today = new Date().toISOString().slice(0, 10);
    const row = this.daily[this.daily.length - 1];
    if (row && row.date === today) {
      row.events[event.event] = (row.events[event.event] ?? 0) + 1;
      if (event.event === "page_view") {
        row.pageViews += 1;
        row.users += 1;
        row.sessions += 1;
      }
      if (event.event === "lead_generated" || event.event === "quotation_submit") {
        row.leads += 1;
        row.conversions += 1;
      }
    }
    this.emit();
  }

  subscribe(fn: () => void) {
    this.listeners.add(fn);
    return () => {
      this.listeners.delete(fn);
    };
  }

  emit() {
    this.listeners.forEach((fn) => fn());
  }

  allEvents(): AnalyticsEvent[] {
    return [...this.sampleEvents, ...this.live].slice(-500);
  }
}

export const warehouse = new Warehouse();
