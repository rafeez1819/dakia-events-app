import { CITIES, CHANNELS } from "./config";
import type {
  Anomaly,
  DailyRollup,
  ForecastPoint,
  FunnelStep,
  IntelSnapshot,
  LeadRecord,
  AnalyticsEvent,
  RealtimeVisitor,
} from "./types";

function sum(rows: DailyRollup[], pick: (d: DailyRollup) => number) {
  return rows.reduce((n, d) => n + pick(d), 0);
}

function delta(curr: number, prev: number) {
  if (!prev) return 0;
  return (curr - prev) / prev;
}

function mean(xs: number[]) {
  if (!xs.length) return 0;
  return xs.reduce((a, b) => a + b, 0) / xs.length;
}

function stdev(xs: number[]) {
  if (xs.length < 2) return 0;
  const m = mean(xs);
  return Math.sqrt(xs.reduce((s, x) => s + (x - m) ** 2, 0) / (xs.length - 1));
}

function detectAnomalies(daily: DailyRollup[]): Anomaly[] {
  const metrics: { key: string; pick: (d: DailyRollup) => number }[] = [
    { key: "users", pick: (d) => d.users },
    { key: "leads", pick: (d) => d.leads },
    { key: "conversions", pick: (d) => d.conversions },
    { key: "conversionValue", pick: (d) => d.conversionValue },
  ];
  const out: Anomaly[] = [];
  for (const metric of metrics) {
    const series = daily.map(metric.pick);
    const m = mean(series);
    const sd = stdev(series) || 1;
    daily.forEach((d, i) => {
      const value = series[i]!;
      const z = (value - m) / sd;
      if (Math.abs(z) >= 2.4) {
        out.push({
          date: d.date,
          metric: metric.key,
          value,
          expected: Math.round(m),
          z: Math.round(z * 100) / 100,
          direction: z > 0 ? "up" : "down",
        });
      }
    });
  }
  return out.sort((a, b) => Math.abs(b.z) - Math.abs(a.z)).slice(0, 8);
}

function forecastFrom(daily: DailyRollup[]): ForecastPoint[] {
  const last = daily.slice(-30);
  const points: ForecastPoint[] = last.map((d) => ({
    date: d.date,
    leads: d.leads,
    value: d.conversionValue,
    kind: "actual",
  }));
  const n = last.length;
  if (n < 5) return points;
  const xs = last.map((_, i) => i);
  const ysL = last.map((d) => d.leads);
  const ysV = last.map((d) => d.conversionValue);
  const regress = (ys: number[]) => {
    const xBar = mean(xs);
    const yBar = mean(ys);
    let num = 0;
    let den = 0;
    xs.forEach((x, i) => {
      num += (x - xBar) * (ys[i]! - yBar);
      den += (x - xBar) ** 2;
    });
    const b = den ? num / den : 0;
    const a = yBar - b * xBar;
    return { a, b };
  };
  const l = regress(ysL);
  const v = regress(ysV);
  const end = new Date(last[n - 1]!.date);
  for (let i = 1; i <= 30; i++) {
    const d = new Date(end);
    d.setDate(d.getDate() + i);
    const x = n - 1 + i;
    points.push({
      date: d.toISOString().slice(0, 10),
      leads: Math.max(0, Math.round(l.a + l.b * x)),
      value: Math.max(0, Math.round(v.a + v.b * x)),
      kind: "forecast",
    });
  }
  return points;
}

function funnelOf(daily: DailyRollup[]): FunnelStep[] {
  const users = sum(daily, (d) => d.users);
  const product = sum(daily, (d) => d.events.product_view ?? 0);
  const spec = sum(daily, (d) => d.events.led_product_view ?? 0);
  const start = sum(daily, (d) => d.events.quotation_start ?? d.events.form_start ?? 0);
  const submit = sum(daily, (d) => d.events.quotation_submit ?? 0);
  const generated = sum(daily, (d) => d.leads);
  const qualified = sum(daily, (d) => d.qualifiedLeads);
  return [
    { id: "visitor", label: "Visitors", count: users },
    { id: "product", label: "Product views", count: product },
    { id: "spec", label: "LED / spec views", count: spec },
    { id: "quote_start", label: "Quote started", count: start },
    { id: "quote_submit", label: "Quote submitted", count: submit },
    { id: "lead", label: "Leads generated", count: generated },
    { id: "qualified", label: "Qualified leads", count: qualified },
  ];
}

const PAGES = [
  { path: "/", views: 0.28, engagement: 48, conv: 0.18 },
  { path: "/#services", views: 0.16, engagement: 62, conv: 0.22 },
  { path: "/#events", views: 0.11, engagement: 57, conv: 0.14 },
  { path: "/#projects", views: 0.09, engagement: 71, conv: 0.19 },
  { path: "/#contact", views: 0.08, engagement: 44, conv: 0.31 },
  { path: "/#capabilities", views: 0.07, engagement: 66, conv: 0.09 },
  { path: "/#about", views: 0.06, engagement: 51, conv: 0.04 },
  { path: "/intel", views: 0.03, engagement: 88, conv: 0.01 },
];

export function buildSnapshot(opts: {
  daily: DailyRollup[];
  leads: LeadRecord[];
  liveEvents: AnalyticsEvent[];
  realtime: RealtimeVisitor[];
  rangeDays?: number;
}): IntelSnapshot {
  const rangeDays = opts.rangeDays ?? 30;
  const daily = opts.daily.slice(-rangeDays);
  const prev = opts.daily.slice(-rangeDays * 2, -rangeDays);
  const users = sum(daily, (d) => d.users);
  const sessions = sum(daily, (d) => d.sessions);
  const engagedSessions = sum(daily, (d) => d.engagedSessions);
  const pageViews = sum(daily, (d) => d.pageViews);
  const leads = sum(daily, (d) => d.leads);
  const qualifiedLeads = sum(daily, (d) => d.qualifiedLeads);
  const conversions = sum(daily, (d) => d.conversions);
  const conversionValue = sum(daily, (d) => d.conversionValue);
  const prevUsers = sum(prev, (d) => d.users);
  const prevLeads = sum(prev, (d) => d.leads);

  const channelMix = CHANNELS.map((name) => ({
    name,
    users: sum(daily, (d) => d.channels[name] ?? 0),
    leads: Math.round(
      sum(daily, (d) => d.leads) *
        ((name === "linkedin" ? 0.28 : name === "paid" ? 0.22 : name === "organic" ? 0.24 : 0.08) as number),
    ),
  }));

  const deviceMix = [
    {
      name: "mobile",
      users: sum(daily, (d) => d.devices.mobile),
      leads: Math.round(leads * 0.38),
    },
    {
      name: "desktop",
      users: sum(daily, (d) => d.devices.desktop),
      leads: Math.round(leads * 0.56),
    },
    {
      name: "tablet",
      users: sum(daily, (d) => d.devices.tablet),
      leads: Math.round(leads * 0.06),
    },
  ];

  const geoMix = CITIES.map((name) => ({
    name,
    users: sum(daily, (d) => d.geos[name] ?? 0),
    leads: Math.round(leads * (name === "Dubai" ? 0.41 : name === "Abu Dhabi" ? 0.22 : 0.06)),
  })).sort((a, b) => b.users - a.users);

  const topPages = PAGES.map((p) => ({
    path: p.path,
    views: Math.round(pageViews * p.views),
    engagement: p.engagement,
    conversions: Math.round(conversions * p.conv),
  }));

  return {
    rangeDays,
    users,
    sessions,
    engagedSessions,
    pageViews,
    engagementRate: sessions ? engagedSessions / sessions : 0,
    avgEngagementSec: daily.length ? Math.round(mean(daily.map((d) => d.avgEngagementSec))) : 0,
    leads,
    qualifiedLeads,
    conversions,
    conversionRate: users ? conversions / users : 0,
    conversionValue,
    usersDelta: delta(users, prevUsers),
    leadsDelta: delta(leads, prevLeads),
    channelMix,
    deviceMix,
    geoMix,
    topPages,
    daily,
    funnel: funnelOf(daily),
    leadsList: opts.leads.slice(-80).reverse(),
    anomalies: detectAnomalies(daily),
    forecast: forecastFrom(opts.daily),
    realtime: opts.realtime,
    liveEvents: opts.liveEvents.slice(-120).reverse(),
  };
}

export function summarizeForAi(s: IntelSnapshot) {
  return {
    rangeDays: s.rangeDays,
    users: s.users,
    usersDeltaPct: Math.round(s.usersDelta * 1000) / 10,
    sessions: s.sessions,
    engagementRatePct: Math.round(s.engagementRate * 1000) / 10,
    leads: s.leads,
    leadsDeltaPct: Math.round(s.leadsDelta * 1000) / 10,
    qualifiedLeads: s.qualifiedLeads,
    conversionRatePct: Math.round(s.conversionRate * 1000) / 10,
    conversionValueAED: s.conversionValue,
    topChannel: [...s.channelMix].sort((a, b) => b.leads - a.leads)[0],
    topGeo: s.geoMix[0],
    deviceMix: s.deviceMix,
    funnel: s.funnel,
    anomalies: s.anomalies.slice(0, 5),
    forecast30Leads: s.forecast.filter((f) => f.kind === "forecast").reduce((n, f) => n + f.leads, 0),
    note: "Aggregated metrics only. No names, emails, phones, or raw user histories.",
  };
}
