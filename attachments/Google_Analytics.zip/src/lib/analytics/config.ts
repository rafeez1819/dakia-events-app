/** GA4 Implementation Specification v2.0 — Dakia Events */

export const GA4_MEASUREMENT_ID = "G-PK86GP1MGY";
export const COLLECT_ENDPOINT = "/api/collect";
export const CONTACT_ENDPOINT = "/api/contact";

export const KEY_EVENTS = [
  "quotation_submit",
  "contact_form_submit",
  "lead_generated",
  "whatsapp_click",
  "phone_click",
  "email_click",
  "led_quote_request",
] as const;

/** Assigned business values in AED — static lead values, not revenue. */
export const EVENT_VALUE_AED: Record<string, number> = {
  quotation_submit: 450,
  contact_form_submit: 450,
  lead_generated: 450,
  led_quote_request: 450,
  rental_quote_submit: 400,
  whatsapp_click: 80,
  phone_click: 120,
  email_click: 60,
  brochure_download: 40,
  specification_download: 35,
};

export const CONTENT_GROUPS: Record<string, string> = {
  "": "home",
  hero: "home",
  about: "about",
  services: "services",
  events: "events",
  clients: "clients",
  capabilities: "capabilities",
  process: "process",
  projects: "projects",
  testimonials: "testimonials",
  contact: "contact",
};

export const PII_KEYS = [
  "email",
  "phone",
  "phone_number",
  "fullName",
  "full_name",
  "name",
  "first_name",
  "last_name",
  "address",
  "company",
  "details",
  "message",
  "password",
  "user_id",
] as const;

export const CHANNELS = [
  "organic",
  "paid",
  "linkedin",
  "instagram",
  "direct",
  "referral",
  "whatsapp",
  "email",
] as const;

export const CITIES = [
  "Dubai",
  "Abu Dhabi",
  "Sharjah",
  "Ajman",
  "Al Ain",
  "Ras Al Khaimah",
  "Riyadh",
  "Doha",
] as const;

export const PRODUCT_TYPES = [
  "LED_VIDEO_WALL",
  "SOUND_SYSTEM",
  "LIGHTING",
  "STAGE_RIGGING",
  "EVENT_PRODUCTION",
  "AV_RENTAL",
] as const;
