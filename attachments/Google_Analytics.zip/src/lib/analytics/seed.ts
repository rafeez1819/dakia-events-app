import { CITIES, CHANNELS, EVENT_VALUE_AED, PRODUCT_TYPES } from "./config";
import type { AnalyticsEvent, DailyRollup, LeadRecord } from "./types";

function mulberry(seed: number) {
  let a = seed >>> 0;
  return () => {
    a += 0x6d2b79f5;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t ^= t + Math.imul(t ^ (t >>> 7), 61 | t);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const EVENT_WEIGHTS: [string, number][] = [
  ["page_view", 1],
  ["user_engagement", 0.62],
  ["scroll", 0.38],
  ["product_view", 0.34],
  ["led_product_view", 0.22],
  ["project_view", 0.18],
  ["fiba_project_view", 0.07],
  ["concert_project_view", 0.06],
  ["exhibition_project_view", 0.05],
  ["form_start", 0.09],
  ["quotation_start", 0.07],
  ["quotation_submit", 0.028],
  ["contact_form_submit", 0.026],
  ["lead_generated", 0.026],
  ["whatsapp_click", 0.045],
  ["phone_click", 0.032],
  ["email_click", 0.018],
  ["led_quote_request", 0.012],
];

export function buildHistory(days = 90, seed = 20260821) {
  const rand = mulberry(seed);
  const daily: DailyRollup[] = [];
  const events: AnalyticsEvent[] = [];
  const leads: LeadRecord[] = [];
  const today = new Date();
  today.setHours(12, 0, 0, 0);

  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const iso = d.toISOString().slice(0, 10);
    const dow = d.getDay();
    const weekend = dow === 5 || dow === 6;
    const wave = 1 + 0.18 * Math.sin((i / days) * Math.PI * 2);
    const campaignBoost = i % 17 === 0 ? 1.35 : 1;
    const users = Math.round((weekend ? 70 : 128) * wave * campaignBoost * (0.85 + rand() * 0.3));
    const sessions = Math.round(users * (1.15 + rand() * 0.2));
    const newUsers = Math.round(users * (0.42 + rand() * 0.12));
    const engagedSessions = Math.round(sessions * (0.58 + rand() * 0.12));
    const pageViews = Math.round(sessions * (2.4 + rand() * 0.8));

    const channels = {} as DailyRollup["channels"];
    const channelShare = [0.31, 0.14, 0.18, 0.09, 0.16, 0.06, 0.04, 0.02];
    CHANNELS.forEach((ch, idx) => {
      channels[ch] = Math.max(1, Math.round(users * channelShare[idx]! * (0.8 + rand() * 0.4)));
    });

    const devices = {
      mobile: Math.round(users * 0.68),
      desktop: Math.round(users * 0.27),
      tablet: Math.max(0, users - Math.round(users * 0.68) - Math.round(users * 0.27)),
    };

    const geos = {} as DailyRollup["geos"];
    const geoShare = [0.38, 0.22, 0.12, 0.09, 0.05, 0.04, 0.06, 0.04];
    CITIES.forEach((city, idx) => {
      geos[city] = Math.max(0, Math.round(users * geoShare[idx]! * (0.85 + rand() * 0.3)));
    });

    const eventCounts: Record<string, number> = {};
    for (const [name, w] of EVENT_WEIGHTS) {
      eventCounts[name] = Math.max(0, Math.round(users * w * (0.75 + rand() * 0.5)));
    }
    eventCounts.page_view = pageViews;

    const conversions =
      (eventCounts.quotation_submit ?? 0) +
      (eventCounts.whatsapp_click ?? 0) +
      (eventCounts.phone_click ?? 0);
    const conversionValue =
      (eventCounts.quotation_submit ?? 0) * EVENT_VALUE_AED.quotation_submit! +
      (eventCounts.whatsapp_click ?? 0) * EVENT_VALUE_AED.whatsapp_click! +
      (eventCounts.phone_click ?? 0) * EVENT_VALUE_AED.phone_click!;
    const leadN = eventCounts.lead_generated ?? 0;
    const qualifiedLeads = Math.round(leadN * (0.38 + rand() * 0.15));

    daily.push({
      date: iso,
      users,
      newUsers,
      sessions,
      engagedSessions,
      pageViews,
      avgEngagementSec: Math.round(42 + rand() * 38),
      channels,
      devices,
      geos,
      events: eventCounts,
      conversions,
      conversionValue,
      leads: leadN,
      qualifiedLeads,
    });

    const sampleN = i < 8 ? 18 : i < 21 ? 6 : 0;
    for (let k = 0; k < sampleN; k++) {
      const [ev] = EVENT_WEIGHTS[Math.floor(rand() * EVENT_WEIGHTS.length)]!;
      const city = CITIES[Math.floor(rand() * CITIES.length)]!;
      const device = rand() > 0.68 ? "desktop" : rand() > 0.08 ? "mobile" : "tablet";
      const ts = d.getTime() + Math.floor(rand() * 86400000);
      events.push({
        event: ev,
        timestamp: ts,
        client_id: `cid.seed${Math.floor(rand() * 90000)}`,
        session_id: `sid.seed${Math.floor(rand() * 90000)}`,
        params: {
          page_location: "https://dakiaevents.com/",
          content_group: ["home", "services", "events", "projects", "contact"][Math.floor(rand() * 5)]!,
          city,
          device_category: device,
          lead_source: CHANNELS[Math.floor(rand() * CHANNELS.length)]!,
        },
      });
    }

    const leadSample = i < 21 ? Math.min(leadN, 3 + Math.floor(rand() * 4)) : 0;
    for (let k = 0; k < leadSample; k++) {
      const pages = 2 + Math.floor(rand() * 7);
      const product = PRODUCT_TYPES[Math.floor(rand() * PRODUCT_TYPES.length)]!;
      const source = CHANNELS[Math.floor(rand() * 5)]!;
      let score = 20 + pages * 6;
      if (product === "LED_VIDEO_WALL") score += 12;
      if (source === "linkedin" || source === "paid") score += 10;
      const device = rand() > 0.45 ? "desktop" : "mobile";
      if (device === "desktop") score += 8;
      score = Math.min(99, Math.round(score + rand() * 10));
      const band = score >= 81 ? "very_high" : score >= 61 ? "high" : score >= 31 ? "medium" : "low";
      leads.push({
        id: `ld-${iso}-${k}`,
        ts: d.getTime() + Math.floor(rand() * 86400000),
        eventType: ["Sports / FIBA", "Corporate Event", "Music Concert", "Exhibition", "Conference"][
          Math.floor(rand() * 5)
        ]!,
        productType: product,
        source,
        city: CITIES[Math.floor(rand() * 4)]!,
        device,
        score,
        band,
        qualified: score >= 61,
      });
    }
  }

  return { daily, events: events.slice(-500), leads: leads.slice(-180) };
}
