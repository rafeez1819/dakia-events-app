import { PII_KEYS } from "./config";

const PII_SET = new Set<string>(PII_KEYS);
const EMAIL_RE = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi;
const PHONE_RE = /(\+?\d[\d\s().-]{7,}\d)/g;

export function stripPiiValue(value: unknown): string | number | boolean | null {
  if (value == null) return null;
  if (typeof value === "number" || typeof value === "boolean") return value;
  const text = String(value);
  return text.replace(EMAIL_RE, "[redacted]").replace(PHONE_RE, "[redacted]");
}

export function sanitizeParams(
  params: Record<string, unknown> | undefined,
): Record<string, string | number | boolean | null> {
  const out: Record<string, string | number | boolean | null> = {};
  if (!params) return out;
  for (const [key, value] of Object.entries(params)) {
    if (PII_SET.has(key) || PII_SET.has(key.toLowerCase())) continue;
    if (key === "user_id") continue;
    out[key] = stripPiiValue(value);
  }
  return out;
}

export function sanitizeEventName(name: string): string {
  return name
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "_")
    .replace(/[^a-z0-9_]/g, "")
    .slice(0, 40);
}
